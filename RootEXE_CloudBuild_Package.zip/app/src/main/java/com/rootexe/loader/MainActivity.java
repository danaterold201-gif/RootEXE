package com.rootexe.loader;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private LinearLayout root, logBox;
    private TextView status;
    private int silver = Color.rgb(224,224,224);
    private int muted = Color.rgb(145,145,145);
    private int panel = Color.rgb(18,18,18);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,5,5));
        getWindow().setNavigationBarColor(Color.rgb(5,5,5));
        buildUi();
    }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(14));
        d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create(bold ? "serif" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private void addGap(LinearLayout l, int h) {
        View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private TextView button(String label) {
        TextView b = text(label, 15, Color.WHITE, true);
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setBackground(bg(Color.rgb(24,24,24), Color.rgb(180,180,180)));
        return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(7,7,7));
        root = vertical(); root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        TextView logo = text("R O O T . E X E", 30, silver, true);
        logo.setLetterSpacing(0.05f);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(64)));
        TextView subtitle = text("O X I D E   /   SURVIVAL ISLAND", 10, muted, false);
        root.addView(subtitle);
        addGap(root, 20);

        LinearLayout statusPanel = vertical();
        statusPanel.setPadding(dp(16), dp(16), dp(16), dp(16));
        statusPanel.setBackground(bg(panel, Color.rgb(65,65,65)));
        root.addView(statusPanel);
        status = text("SYSTEM STATUS  •  READY TO CHECK", 13, silver, true);
        statusPanel.addView(status);
        addGap(statusPanel, 10);
        statusPanel.addView(text("Android 15  ·  Root access is checked on demand", 11, muted, false));
        addGap(root, 16);

        TextView start = button("▶   START");
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        // Launch action intentionally disabled for this prototype.
        addGap(root, 16);

        LinearLayout features = vertical();
        features.setPadding(dp(16), dp(16), dp(16), dp(16));
        features.setBackground(bg(panel, Color.rgb(48,48,48)));
        root.addView(features);
        features.addView(text("MODULES", 12, muted, true));
        addGap(features, 12);
        features.addView(moduleRow("ESP", "Visualisation module • not connected"));
        addGap(features, 8);
        features.addView(moduleRow("SILENT AIM", "Test-environment module • not connected"));
        addGap(root, 16);

        root.addView(text("CONSOLE", 12, muted, true));
        addGap(root, 8);
        logBox = vertical();
        logBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        logBox.setBackground(bg(Color.rgb(10,10,10), Color.rgb(42,42,42)));
        root.addView(logBox);
        addLog("Root.exe Loader initialized.");
        addLog("Game modules are placeholders and are not active.");
        addGap(root, 16);
        root.addView(text("GOTHIC MONOCHROME INTERFACE  •  BUILD 1.0", 9, muted, false));
    }

    private View moduleRow(String name, String description) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(bg(Color.rgb(13,13,13), Color.rgb(42,42,42)));
        row.addView(text(name, 14, silver, true));
        TextView desc = text(description, 10, muted, false);
        row.addView(desc);
        return row;
    }

    private void addLog(String line) {
        TextView t = text("›  " + line, 10, muted, false);
        t.setGravity(Gravity.LEFT);
        logBox.addView(t);
    }


}